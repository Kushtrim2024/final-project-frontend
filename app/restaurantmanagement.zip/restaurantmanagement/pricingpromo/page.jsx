import React from "react";

function page() {
  return <div>Pricing Promotions</div>;
}

export default page;
